package com.example.quotes.domain.model

data class QuoteModel(val id: Int,
                      val quote:String,
                      val author: String)
